import glob
import os
import pandas as pd
import shutil

categories = os.listdir(
    "/work/masatate/dataset/ObjectStatefromAction/MOST_dataset/test_annotations"
)
category_list = []
id_list = []
for cat in categories:
    annot_files = glob.glob(
        os.path.join(
            "/work/masatate/dataset/ObjectStatefromAction/MOST_dataset/test_annotations",
            cat,
            "*.csv",
        )
    )
    category_list.extend([cat] * len(annot_files))
    id_list.extend([os.path.basename(f).split(".")[0] for f in annot_files])

df = pd.DataFrame({"category": category_list, "video_id": id_list})
df.to_csv("test_video_ids.csv", index=False)


# folder_a = "/work/masatate/dataset/create_multistate_dataset_v3/validation/data"
# folder_b = (
#     "/work/masatate/dataset/ObjectStatefromAction/MOST_dataset/pl_valid_annotations"
# )
# category_list = ["apple", "egg", "flour", "shirt", "tire", "wire"]

# for cat in category_list:
#     annot_files = glob.glob(os.path.join(folder_a, cat, "annotations", "*.csv"))
#     for f in annot_files:
#         shutil.copy(f, os.path.join(folder_b, cat, os.path.basename(f)))
#         print(f)
#         print(os.path.join(folder_b, cat, os.path.basename(f)))
#         print()
